
import type { LocationData } from '../../types';

export const officeLocation: LocationData = {
  id: 'office',
  name: 'Stasi Office',
  image: '/assets/img/office.png',
  scenes: {
    start: {
      narrative: "You enter a small, austere office. The air is thick with the smell of stale cigarette smoke and paranoia. There is a large metal desk, a locked filing cabinet, and a single window overlooking the same bleak street. The door clicks shut behind you, locking automatically.",
      actions: [
        { text: 'Examine the desk', transition: { sceneId: 'desk' } },
        { text: 'Look at the filing cabinet', transition: { sceneId: 'cabinet_locked' } },
        { text: 'Look out the window', transition: { sceneId: 'office_window' } },
        { text: 'Try the door to the hallway', transition: { sceneId: 'door_is_locked' } },
      ],
    },
    door_is_locked: {
        narrative: "You try the door, but it's locked tight. It seems to have locked automatically behind you. There must be another way out.",
        actions: [
            { text: 'Examine the desk', transition: { sceneId: 'desk' } },
            { text: 'Look at the filing cabinet', transition: { sceneId: 'cabinet_locked' } },
            { text: 'Look out the window', transition: { sceneId: 'office_window' } },
        ]
    },
    desk: {
      narrative: "The metal desk is surprisingly tidy. A black telephone sits silently. A single manila folder lies in the center. There is also an ashtray filled with crushed cigarette butts.",
      actions: [
        { text: 'Open the folder', transition: { sceneId: 'read_folder' }, showIf: { noneSet: ['dossier_read'] } },
        { text: 'Look at your dossier again', transition: { sceneId: 'read_folder_again' }, showIf: { allSet: ['dossier_read'] } },
        { text: 'Check the ashtray', transition: { sceneId: 'ashtray' } },
        { text: 'Go back', transition: { sceneId: 'start' } },
      ],
    },
    read_folder: {
      narrative: "You open the folder. Inside is a dossier... with your face staring back at you from a black and white photograph. Your name is typed at the top, along with the word 'VERRÄTER' (TRAITOR) in red ink. Your cover is blown. Tucked behind your file is a small, silver key.",
      onEnter: { addsItem: 'Silver key', setsFlag: 'dossier_read' },
      actions: [
        { text: 'Take the key and close the folder', transition: { sceneId: 'desk' } },
      ],
    },
    read_folder_again: {
        narrative: "You look at the dossier again. Your face stares back. The red 'VERRÄTER' stamp seems to burn into the page. There is nothing else to be found here.",
        actions: [
            { text: 'Close the folder', transition: { sceneId: 'desk'}}
        ]
    },
    ashtray: {
      narrative: "A glass ashtray overflowing with butts. Nothing of interest here.",
      actions: [
        { text: 'Go back to the desk', transition: { sceneId: 'desk' } },
      ],
    },
    cabinet_locked: {
      narrative: "A heavy, grey filing cabinet stands against the wall. It's locked with a small, intricate lock.",
      itemUse: { 
        'Silver key': { transition: { sceneId: 'cabinet_unlocked' }, consumed: false } 
      },
      actions: [
        { text: 'Go back', transition: { sceneId: 'start' } },
      ],
    },
    cabinet_unlocked: {
      narrative: "The silver key fits perfectly. You turn it, and the lock on the cabinet opens with a soft click.",
      actions: [
        { text: 'Open the drawers', transition: { sceneId: 'cabinet_contents' }, showIf: { noneSet: ['escape_items_found'] } },
        { text: 'Look through the files again', transition: { sceneId: 'cabinet_searched' }, showIf: { allSet: ['escape_items_found'] } },
        { text: 'Leave it for now', transition: { sceneId: 'start' } },
      ],
    },
    cabinet_contents: {
      narrative: "You pull open a drawer. It's filled with files on various individuals, surveillance reports and personal details. In the back of the drawer, you find a passport with a new identity and a train ticket to West Berlin for tomorrow night. This is your way out.",
      onEnter: { addsItem: 'Fake passport and ticket', setsFlag: 'escape_items_found' },
      actions: [
        { text: 'Take the items and close the drawer', transition: { sceneId: 'cabinet_unlocked' } },
      ],
    },
    cabinet_searched: {
      narrative: "You look through the files again, but you've already taken the only things of value to you. The rest are just grim records of other lives.",
      actions: [
        { text: 'Close the drawer', transition: { sceneId: 'cabinet_unlocked' } }
      ]
    },
    end_game_preview: {
      narrative: "You have what you need. A chance. Now you just need to survive until tomorrow night and find a way out of this building. The story will continue...",
      actions: [
        { text: 'Continue exploring the office', transition: { sceneId: 'start' } },
      ],
    },
    office_window: {
      narrative: "You look out the window. It's the same view as from your room, but from a different angle. The black Trabant is still there. Unmoving. Watching.",
      actions: [
        { text: 'Step away from the window', transition: { sceneId: 'start' } },
      ],
    },
  },
};
