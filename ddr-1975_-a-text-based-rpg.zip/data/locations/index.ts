import type { LocationData } from '../../types';
import { roomLocation } from './room';
import { hallwayLocation } from './hallway';
import { officeLocation } from './office';

// This is the registry of all locations in the game.
// To add a new location, import it here and add it to the locations object.
export const locations: Record<string, LocationData> = {
  [roomLocation.id]: roomLocation,
  [hallwayLocation.id]: hallwayLocation,
  [officeLocation.id]: officeLocation,
};

// Define the starting point of the game.
export const initialLocationId: string = 'room';
export const initialSceneId: string = 'start';
export const initialInventory: string[] = [
    "A single cigarette", 
    "A book of matches", 
    "A worn photo of a woman",
    "A codebook",
    "A fountain pen",
    "A small, concealed knife"
];