
import type { LocationData } from '../../types';

export const roomLocation: LocationData = {
  id: 'room',
  name: 'Sparselly Furnished Room',
  image: '/assets/img/room.png',
  scenes: {
    start: {
      narrative:
        "You awaken in a sparsely furnished room, the kind that feels cold even in summer. The year is 1975, the city East Berlin. A single bare bulb hangs from the ceiling, casting long shadows. In front of you is a heavy wooden door. On a small table, you see a worn leather notebook and a pack of cigarettes.",
      actions: [
        { text: 'Examine the door', transition: { sceneId: 'door_locked' } },
        { text: 'Read the notebook', transition: { sceneId: 'notebook_contents' } },
        { text: 'Look out the window', transition: { sceneId: 'window_view' } },
        { text: 'Check your pockets', transition: { sceneId: 'check_pockets' } },
        { text: 'Listen for any sounds', transition: { sceneId: 'listen' } },
      ],
    },
    door_locked: {
      narrative:
        "You try the handle. The door is locked tight. It's a sturdy, old-fashioned lock, the kind that requires a physical key. There's no getting through without one.",
      actions: [
        { text: 'Step back from the door', transition: { sceneId: 'start' } },
        { text: 'Search for a key', transition: { sceneId: 'search_for_key' }, showIf: { noneSet: ['room_key_found']}},
        { text: 'Check the loose floorboard again', transition: { sceneId: 'floorboard_empty'}, showIf: { allSet: ['room_key_found']}},
        { text: 'Read the notebook', transition: { sceneId: 'notebook_contents' } },
        { text: 'Look out the window', transition: { sceneId: 'window_view' } },
        { text: 'Try to pick the lock', transition: { sceneId: 'pick_lock_fail' } },
      ],
      itemUse: {
        'Small brass key': {
          transition: { sceneId: 'door_unlocked' },
          consumed: false,
        },
      },
    },
    pick_lock_fail: {
        narrative: "You don't have the right tools for this. The lock is too complex for brute force.",
        actions: [
            { text: 'Step back from the door', transition: { sceneId: 'start' } },
            { text: 'Search for a key', transition: { sceneId: 'search_for_key' }, showIf: { noneSet: ['room_key_found']}},
            { text: 'Check the loose floorboard again', transition: { sceneId: 'floorboard_empty'}, showIf: { allSet: ['room_key_found']}},
            { text: 'Read the notebook', transition: { sceneId: 'notebook_contents' } },
            { text: 'Look out the window', transition: { sceneId: 'window_view' } },
            { text: 'Examine the lock again', transition: { sceneId: 'door_locked' } },
        ]
    },
    notebook_contents: {
      narrative:
        "You open the worn leather notebook. Most pages are blank, but on the first page, a simple message is written in neat cursive: 'The key is under the loose floorboard. Trust no one.'",
      actions: [
        { text: 'Search for a loose floorboard', transition: { sceneId: 'search_for_key' }, showIf: { noneSet: ['room_key_found']}},
        { text: 'Check the loose floorboard again', transition: { sceneId: 'floorboard_empty'}, showIf: { allSet: ['room_key_found']}},
        { text: 'Examine the door', transition: { sceneId: 'door_locked' } },
        { text: 'Look out the window', transition: { sceneId: 'window_view' } },
        { text: 'Put the notebook down', transition: { sceneId: 'start' } },
        { text: 'Tear out the page', transition: { sceneId: 'page_torn' }, showIf: { noneSet: ['page_torn'] } },
      ],
    },
    page_torn: {
      narrative: "You carefully tear the page from the notebook. The cryptic message is now a small scrap in your hand. The rest of the notebook is just empty pages.",
      onEnter: { addsItem: 'Scrap of paper with note', setsFlag: 'page_torn' },
      actions: [
        { text: 'Search for a loose floorboard', transition: { sceneId: 'search_for_key' }, showIf: { noneSet: ['room_key_found']}},
        { text: 'Check the loose floorboard again', transition: { sceneId: 'floorboard_empty'}, showIf: { allSet: ['room_key_found']}},
        { text: 'Examine the door', transition: { sceneId: 'door_locked' } },
        { text: 'Look out the window', transition: { sceneId: 'window_view' } },
        { text: 'Put the notebook down', transition: { sceneId: 'start' } },
        { text: 'Pocket the scrap of paper', transition: { sceneId: 'start' } },
      ],
    },
    window_view: {
      narrative:
        'You peer through the grimy windowpane. Below, a grey, cobblestone street is empty save for a black Trabant parked across the way. The sky is overcast. You feel watched.',
      actions: [
        { text: 'Step away from the window', transition: { sceneId: 'start' } },
        { text: 'Examine the Trabant more closely', transition: { sceneId: 'window_view_focus' } },
        { text: 'Read the notebook', transition: { sceneId: 'notebook_contents' } },
        { text: 'Examine the door', transition: { sceneId: 'door_locked' } },
        { text: 'Search for a key', transition: { sceneId: 'search_for_key' }, showIf: { noneSet: ['room_key_found']}},
      ],
    },
    window_view_focus: {
        narrative: "You focus on the black car. It's impossible to see inside from this distance and through the glare. It just sits there, silent and menacing, a dark shape against the grey street.",
        actions: [
          { text: 'Step away from the window', transition: { sceneId: 'start' } },
          { text: 'Wait to see if anyone appears', transition: { sceneId: 'window_view_wait' } },
          { text: 'Read the notebook', transition: { sceneId: 'notebook_contents' } },
          { text: 'Examine the door', transition: { sceneId: 'door_locked' } },
          { text: 'Search for a key', transition: { sceneId: 'search_for_key' }, showIf: { noneSet: ['room_key_found']}},
        ],
    },
    window_view_wait: {
        narrative: "You watch the car for several long minutes. Nothing changes. No one gets in or out. The street remains empty. The silence outside is as profound as the silence in the room.",
        actions: [
          { text: 'Step away from the window', transition: { sceneId: 'start' } },
          { text: 'Read the notebook', transition: { sceneId: 'notebook_contents' } },
          { text: 'Examine the door', transition: { sceneId: 'door_locked' } },
          { text: 'Search for a key', transition: { sceneId: 'search_for_key' }, showIf: { noneSet: ['room_key_found']}},
          { text: 'Give up watching', transition: { sceneId: 'window_view' } },
        ],
    },
    check_pockets: {
        narrative: "You pat down your pockets. You feel the familiar shapes of your inventory items. Nothing new has appeared.",
        actions: [
            { text: 'Return to observing the room', transition: { sceneId: 'start' } },
            { text: 'Examine the door', transition: { sceneId: 'door_locked' } },
            { text: 'Read the notebook', transition: { sceneId: 'notebook_contents' } },
            { text: 'Look out the window', transition: { sceneId: 'window_view' } },
            { text: 'Listen for any sounds', transition: { sceneId: 'listen' } },
        ]
    },
    listen: {
        narrative: "You stand perfectly still, straining to hear anything beyond the low hum of the electricity in the walls. There's nothing. The building is utterly silent. It's an unnerving quiet.",
        actions: [
            { text: 'Stop listening', transition: { sceneId: 'start' } },
            { text: 'Examine the door', transition: { sceneId: 'door_locked' } },
            { text: 'Read the notebook', transition: { sceneId: 'notebook_contents' } },
            { text: 'Look out the window', transition: { sceneId: 'window_view' } },
            { text: 'Check your pockets', transition: { sceneId: 'check_pockets' } },
        ]
    },
    search_for_key: {
      narrative:
        'You scan the floor and find a board near the corner that looks slightly out of place. Prying it up with your fingertips, you find a small, brass key nestled in the dust below. You pick it up.',
      actions: [
        { text: 'Take the key and go to the door', transition: { sceneId: 'door_locked' } },
        { text: 'Put the floorboard back', transition: { sceneId: 'start' } },
        { text: 'Examine the key', transition: { sceneId: 'examine_key' } },
      ],
      onEnter: {
        addsItem: 'Small brass key',
        setsFlag: 'room_key_found',
      },
    },
     floorboard_empty: {
      narrative: "You lift the loose floorboard again. The dusty space where the key used to be is now empty.",
      actions: [
        { text: 'Put the floorboard back', transition: { sceneId: 'start' } },
        { text: 'Go to the door', transition: { sceneId: 'door_locked' } },
      ],
    },
     examine_key: {
      narrative: "It's a simple, old-fashioned brass key. It feels solid in your hand. There are no markings on it.",
      actions: [
        { text: 'Go to the door', transition: { sceneId: 'door_locked' } },
        { text: 'Put the floorboard back', transition: { sceneId: 'start' } },
        { text: 'Look out the window', transition: { sceneId: 'window_view' } },
        { text: 'Read the notebook', transition: { sceneId: 'notebook_contents' } },
        { text: 'Pocket the key', transition: { sceneId: 'start' } },
      ],
    },
    door_unlocked: {
      narrative:
        "Using the small brass key, you unlock the door. It makes a satisfying 'click'. The way forward is open.",
      actions: [
        { text: 'Open the door and step out', transition: { locationId: 'hallway', sceneId: 'start' } },
        { text: 'Look back at the room', transition: { sceneId: 'start' } },
        { text: 'Lock the door again', transition: { sceneId: 'door_locked' } },
        { text: 'Listen at the door', transition: { sceneId: 'listen_at_unlocked_door' } },
        { text: 'Take a moment to prepare', transition: { sceneId: 'door_unlocked' } },
      ],
    },
    listen_at_unlocked_door: {
      narrative: "You press your ear to the cool wood of the unlocked door. You hear the same profound silence as before. Whatever awaits you, it's not making any noise.",
      actions: [
        { text: 'Open the door and step out', transition: { locationId: 'hallway', sceneId: 'start' } },
        { text: 'Look back at the room', transition: { sceneId: 'start' } },
        { text: 'Lock the door again', transition: { sceneId: 'door_locked' } },
        { text: 'Stop listening', transition: { sceneId: 'door_unlocked' } },
        { text: 'Take a moment to prepare', transition: { sceneId: 'door_unlocked' } },
      ]
    }
  },
};
