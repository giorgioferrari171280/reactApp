
import type { LocationData } from '../../types';

export const hallwayLocation: LocationData = {
  id: 'hallway',
  name: 'Dimly Lit Hallway',
  image: '/assets/img/hallway.png',
  scenes: {
    start: {
      narrative:
        "You step into a long, narrow hallway. It's dimly lit by a single, flickering bulb far down the corridor and smells of dust and decay. The silence is heavy. The door to the room you just left clicks shut behind you. You see another door at the far end of the hall, and a staircase going down to your right.",
      actions: [
        { text: 'Examine the far door', transition: { sceneId: 'examine_far_door' } },
        { text: 'Head towards the staircase', transition: { sceneId: 'staircase' } },
        { text: 'Try the door you came from', transition: { locationId: 'room', sceneId: 'door_locked' } },
        { text: 'Search the hallway', transition: { sceneId: 'search_hallway' } },
      ],
    },
    examine_far_door: {
        narrative: "You approach the door at the end of the hall. It's made of dark, heavy wood and has a brass handle. You try the handle, but it's locked.",
        actions: [
          { text: 'Step back', transition: { sceneId: 'start' } },
          { text: 'Go to the staircase', transition: { sceneId: 'staircase' } },
          { text: 'Search the hallway for a key', transition: { sceneId: 'search_hallway' } },
        ],
        itemUse: {
            'Iron key': {
                transition: { locationId: 'office', sceneId: 'start' },
                consumed: false,
            }
        }
      },
      staircase: {
        narrative: "You move towards the dark opening of the staircase. It descends into darkness. A cold draft comes from below. You're not sure you want to go down there just yet.",
        actions: [
          { text: 'Go back to the hallway', transition: { sceneId: 'start' } },
          { text: 'Go to the far door', transition: { sceneId: 'examine_far_door' } },
        ],
      },
      search_hallway: {
        narrative: "You run your eyes over the peeling wallpaper and worn floorboards. Near the floor, one of the bricks in the wall looks loose.",
        actions: [
            { text: 'Examine the loose brick', transition: { sceneId: 'find_key' }, showIf: { noneSet: ['hallway_key_found']}},
            { text: 'Examine the loose brick again', transition: { sceneId: 'brick_empty'}, showIf: { allSet: ['hallway_key_found']}},
            { text: 'Stop searching', transition: { sceneId: 'start' } },
        ],
      },
      find_key: {
        narrative: "You pry the loose brick from the wall. Tucked inside the cavity is a small, cold, iron key. You take it.",
        onEnter: { addsItem: 'Iron key', setsFlag: 'hallway_key_found' },
        actions: [
            { text: 'Take the key and step back', transition: { sceneId: 'start' } }
        ]
      },
      brick_empty: {
        narrative: "You check the loose brick again. The cavity behind it is empty.",
        actions: [
          { text: 'Put the brick back', transition: { sceneId: 'start'}}
        ]
      }
  },
};
