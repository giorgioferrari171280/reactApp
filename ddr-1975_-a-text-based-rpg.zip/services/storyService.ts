
import type { GameState, Action } from '../types';
import { locations, initialLocationId, initialSceneId, initialInventory } from '../data/locations';

const getSceneState = (locationId: string, sceneId: string, inventory: string[], flags: Record<string, boolean>): GameState => {
    const location = locations[locationId];
    if (!location) {
        console.error(`Location with id "${locationId}" not found.`);
        // Fallback to initial state if location is invalid
        return getSceneState(initialLocationId, initialSceneId, initialInventory, {});
    }
    
    const scene = location.scenes[sceneId];
    if (!scene) {
        console.error(`Scene with id "${sceneId}" in location "${locationId}" not found.`);
        // Fallback to the first scene of the location or the initial game state
        const firstSceneId = Object.keys(location.scenes)[0] || initialSceneId;
        return getSceneState(locationId, firstSceneId, inventory, flags);
    }

    let finalInventory = [...inventory];
    if (scene.onEnter?.addsItem && !finalInventory.includes(scene.onEnter.addsItem)) {
        finalInventory.push(scene.onEnter.addsItem);
    }

    const newFlags = { ...flags };
    if(scene.onEnter?.setsFlag) {
        newFlags[scene.onEnter.setsFlag] = true;
    }

    const availableActions = scene.actions.filter(action => {
        if (!action.showIf) {
            return true; // Always show if no conditions
        }

        const { allSet = [], noneSet = [] } = action.showIf;

        const allConditionsMet = allSet.every(flag => newFlags[flag]);
        const noneConditionsMet = noneSet.every(flag => !newFlags[flag]);

        return allConditionsMet && noneConditionsMet;
    });

    return {
        locationId,
        locationName: location.name,
        imageUrl: location.image,
        sceneId,
        narrative: scene.narrative,
        actions: availableActions.map(a => a.text),
        inventory: finalInventory,
        flags: newFlags
    };
};

export const getInitialGameState = async (): Promise<GameState> => {
    return Promise.resolve(getSceneState(initialLocationId, initialSceneId, initialInventory, {}));
};

export const getGameStateAfterAction = async (actionText: string, currentState: GameState): Promise<GameState> => {
    const location = locations[currentState.locationId];
    const scene = location.scenes[currentState.sceneId];
    
    // We must filter the actions again to find the correct one, because currentState.actions is just a list of strings
    const action = scene.actions.find(a => a.text === actionText);

    if (action) {
        const { transition } = action;
        const nextLocationId = transition.locationId || currentState.locationId;
        const nextSceneId = transition.sceneId;
        return Promise.resolve(getSceneState(nextLocationId, nextSceneId, currentState.inventory, currentState.flags));
    }
    
    const fallbackState = {
        ...currentState,
        narrative: `You try to '${actionText}', but nothing happens.\n\n${scene.narrative}`,
    };
    return Promise.resolve(fallbackState);
};

export const getGameStateAfterItemUse = async (item: string, currentState: GameState): Promise<GameState> => {
    const location = locations[currentState.locationId];
    const scene = location.scenes[currentState.sceneId];
    const itemRule = scene.itemUse?.[item];

    if (itemRule) {
        const { transition, consumed } = itemRule;
        let newInventory = [...currentState.inventory];
        if (consumed) {
            newInventory = newInventory.filter(i => i !== item);
        }
        const nextLocationId = transition.locationId || currentState.locationId;
        const nextSceneId = transition.sceneId;

        return Promise.resolve(getSceneState(nextLocationId, nextSceneId, newInventory, currentState.flags));
    }

     const fallbackState = {
        ...currentState,
        narrative: `You try to use the ${item}, but it has no effect here.\n\n${scene.narrative}`,
    };
    return Promise.resolve(fallbackState);
};
