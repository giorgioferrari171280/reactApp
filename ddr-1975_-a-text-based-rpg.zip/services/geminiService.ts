import { GoogleGenAI, GenerateImagesResponse } from "@google/genai";

if (!process.env.API_KEY) {
  throw new Error("The API_KEY environment variable is not set. Please provide it to enable image generation.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

/**
 * Generates an image based on the narrative text.
 * @param narrative The descriptive text of the current game scene.
 * @param locationName The name of the current location.
 * @returns A base64 encoded image string.
 */
export const generateSceneImage = async (narrative: string, locationName: string): Promise<string> => {
  try {
    const prompt = `
      A realistic, atmospheric photo representing this scene from a Cold War spy thriller set in East Berlin, DDR, 1975.
      Style: Gritty, noir aesthetic, cinematic lighting, slightly desaturated colors, high contrast, subtle film grain.
      Perspective: First-person point of view.
      Location: ${locationName}
      Scene Description: "${narrative}"
      The image must NOT contain any people, text, or user interface elements. It should focus entirely on the environment, objects, and mood described.
    `;

    const response: GenerateImagesResponse = await ai.models.generateImages({
        model: 'imagen-3.0-generate-002',
        prompt: prompt,
        config: { numberOfImages: 1, outputMimeType: 'image/jpeg' },
    });

    if (response.generatedImages && response.generatedImages.length > 0 && response.generatedImages[0].image.imageBytes) {
      const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
      return `data:image/jpeg;base64,${base64ImageBytes}`;
    } else {
      throw new Error("Image generation failed: No images were returned by the API.");
    }
  } catch (error) {
    console.error("Error generating image with Gemini API:", error);
    // Re-throw the error to be handled by the calling component.
    // The component can then decide not to update the image URL.
    throw error;
  }
};
